# import sys
import boto3
# import logging
import pymysql
import json
import csv

#Let's set the Configuration Values
endpoint = 'ag-database-1.ctmkzdmsuggv.us-east-1.rds.amazonaws.com'
username = 'admin'
password = 'Password!'
db_name = 'agdb'

#Connection
conn = pymysql.connect(host=endpoint, user=username, passwd=password, db=db_name)

# def handler():
#     cursor = conn.cursor()
#     cursor.execute('SELECT * from questions')

#     rows = cursor.fetchall()

#     for row in rows:
#         print("{0} {1} {2} {3} {4} {5}".format(row[0], row[1], row[2], row[3], row[4], row[5]))

# handler()



s3_client = boto3.client('s3')



def lambda_handler(event, context):

    # Get the S3 bucket and key from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    csv_file = event['Records'][0]['s3']['object']['key']
    csv_file_obj = s3_client.get_object(Bucket=bucket, Key=csv_file)
    lines = csv_file_obj['Body'].read().decode('utf-8').splitlines()

    results = []
    for row in csv.DictReader(lines):
        results.append(tuple(row.values()))


    with conn.cursor() as cursor:
        for row in results:
            # Insert new question into the database
            sql = "INSERT INTO questions (Question_ID, Question_TEXT, Choice_A, Choice_B, Choice_C, Choice_D, Correct_Answer) VALUES ("+ row[0] + "," + row[1] + "," + row[2] + "," + row[3] + "," + row[4] + "," + row[5] + ","+ row[6] +")"
            cursor.execute(sql)
        conn.commit()


    with conn.cursor() as cursor:
        sql = "SELECT * from questions"
        cursor.execute(sql)
        query_results = cursor.fetchall()
        print(query_results)

    return "Added %d items to RDS MySQL table"